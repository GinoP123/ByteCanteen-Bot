#!/opt/homebrew/Caskroom/miniconda/base/bin/python3

import os, glob
import sys
import json
import time
sys.path.append(f"{os.path.dirname(sys.argv[0])}/..")
import settings

if os.path.exists(settings.session_path):
  with open(settings.session_path) as infile:
    session = json.load(infile)

  print(f"✅ Detected LARK_SESSION env var (length {len(session['session'])})")
  choice = input("Save it to .session.json? (Y/n): ").lower().strip()
  if (choice != 'y'):
    print("Exiting Without Session Update")
    exit(1)
else:
  session = {'session': None, 'updatedAt': 0}


session['updatedAt'] = time.time_ns() // settings.nano_per_micro_second

print('\nHow to obtain LARK_SESSION:')
print('\t1. Open Lark web (https://www.larksuite.com)')
print('\t2. Press F12 to open DevTools')
print('\t3. Application → Cookies → find the entry named "session"')
print('\t4. Copy its Value')

session_value = input('\nPaste the session value (press Enter to skip): ').strip()
if session_value == '':
  print('⚠️  Skipped session config; you can later set the LARK_SESSION env var or create .session.json manually')
  exit(1)
session['session'] = session_value

with open(settings.session_path, 'w') as outfile:
  json.dump(session, outfile, indent=4)

