#!/opt/homebrew/Caskroom/miniconda/base/bin/python3

import os, glob
import sys
sys.path.append(f"{os.path.dirname(sys.argv[0])}/..")
import settings
import datetime
import time
import json


def main():
  with open(settings.config_path) as infile:
    d = json.load(infile)
    if 'sessionTtlDays' in d and d['sessionTtlDays'] > 0:
      session.ttlDays = d['sessionTtlDays']
    if 'sessionWarnDays' in d and d['sessionWarnDays'] >= 0:
      session.warnDays = d['sessionWarnDays']

  base = {
    'ttlDays': settings.ttlDays,
    'warnDays': settings.warnDays,
    'ageDays': None,
    "daysLeft": None,
    "updatedAt": None,
    "level": None,
    "source": None,
    "message": None
  }


  session = {}
  if os.path.exists(settings.session_path):
    with open(settings.session_path) as infile:
      session = json.load(infile)
    base['source'] = 'file'

    now = time.time_ns() // settings.nano_per_micro_second
    updatedAt = session['updatedAt']
    ageDays = max(0, (now - updatedAt) / settings.DAY_MS)
    daysLeft = settings.ttlDays - ageDays

    base['ageDays'] = eval(f"{ageDays:.1f}")
    base['daysLeft'] = eval(f"{daysLeft:.1f}")
    base['updatedAt'] = str(datetime.datetime.fromtimestamp(updatedAt / settings.micro_per_second).replace(microsecond=0))

    base['message'] = f'Lark session is ~{ageDays:.1f}d old; estimated ~{daysLeft:.1f}d left (of ~{settings.ttlDays:.1f}d)'
    base['level'] = 'ok'

    if ageDays >= settings.ttlDays:
      base['level'] = 'expired'
      base['message'] = f'Lark session is ~{ageDays:.1f}d old (estimated ~{ttlDays}d lifetime) — it has likely expired.'
      base['message'] += ' Paste a fresh Lark web `session` cookie before the next request.'
    elif daysLeft <= settings.warnDays:
      base['level'] = 'warn'
      base['message'] = f"{base['message']}. Re-paste your Lark web `session` cookie soon to avoid a mid-request failure."

  elif os.environ['LARK_SESSION']:
    session['session'] = os.environ['LARK_SESSION']
    base['message'] = 'Lark session is taken from $LARK_SESSION; its age is unknown, so expiry cannot be estimated.'
    base['message'] += ' Re-export it if requests start failing with `invalid larksession`.'
    base['level'] = 'Unknown'
    base['source'] = 'env'
  else:
    base['level'] = 'absent'
    base['message'] = 'No Lark session configured (.session.json absent and $LARK_SESSION unset).'
    base['message'] += ' Paste your Lark web `session` cookie to set one.'


  print((json.dumps(base, indent=2)))



if __name__ == '__main__':
  main()

