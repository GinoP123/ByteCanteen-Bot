import fs from 'fs';
import path from 'path';
import { sessionStatus } from './session_status.mjs';

/**
 * San Jose canteen "food-truck / pre-order" module.
 *
 * Auth: the ordering API (smartcanteen/app/inner-order/) authenticates with a
 * `session_id` cookie. That session_id is auto-derived from the SAME Lark
 * session as the menu API (.session.json / LARK_SESSION):
 *     mina/v2/login (silent)  ->  code  ->  h5/login?code=  ->  Set-Cookie: session_id
 * It is cached in .order_session.json with the cookie's max-age (~15 days) and
 * auto-re-minted on expiry or if the server rejects it (401). No manual paste,
 * no browser, no msToken (proven irrelevant to auth).
 *
 *   list   read-only: orderable food-truck stalls/items for a building/date/meal
 *   whoami read-only: validate session + show resolved ordering identity
 *   order  places a REAL order by default; --dry-run only previews
 *   cancel cancels for REAL by default; --dry-run only previews
 */

const SKILL_DIR = path.join(import.meta.dirname || '.', '..');
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const ORDER_SESSION_PATH = path.join(SKILL_DIR, '.order_session.json');
const LARK_SESSION_PATH = path.join(SKILL_DIR, '.session.json');

const APPID = 'cli_9f847db13cead00d';
const HOST = 'https://aplus.bytedance.com';
const MENU_URL = `${HOST}/smartcanteen/app/inner-order/menu/v3`;
const SUBMIT_URL = `${HOST}/smartcanteen/app/inner-order/submit-order/batch`;
const CANCEL_URL = `${HOST}/smartcanteen/app/inner-order/cancel-order`;
const USER_INFO_URL = `${HOST}/smartcanteen/app/mini-program/h5/user_info`;
const MINA_LOGIN_URL = 'https://open.feishu.cn/open-apis/mina/v2/login';
const H5_LOGIN_URL = `${HOST}/smartcanteen/app/mini-program/h5/login`;
const DEFAULT_MAXAGE = 1296000; // 15 days, the observed session_id cookie TTL

function loadConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
}

function fail(msg) {
  console.error(JSON.stringify({ error: msg }, null, 2));
  process.exit(1);
}

/** The Lark session used to derive everything: .session.json {session} or LARK_SESSION env. */
function getLarkSession() {
  try {
    const d = JSON.parse(fs.readFileSync(LARK_SESSION_PATH, 'utf-8'));
    if (d?.session) return d.session;
  } catch { }
  return process.env.LARK_SESSION || '';
}

function readJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

/**
 * Mint a fresh ordering session_id from the Lark session, silently:
 *   mina/v2/login -> code -> h5/login?code= -> Set-Cookie: session_id (+ max-age)
 * Returns { session_id, expiresAt }.
 */
async function mintSessionId() {
  const lark = getLarkSession();
  if (!lark) {
    throw new Error('.session.json / LARK_SESSION missing — cannot derive the ordering session. Refresh .session.json first.');
  }
  const m = await fetch(MINA_LOGIN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionid: lark, appid: APPID }),
  });
  const mj = readJson(await m.text());
  const code = mj?.data?.code;
  if (!code) throw new Error(`mina login failed (LARK_SESSION may be expired — refresh .session.json): ${JSON.stringify(mj)}`);

  const url = new URL(H5_LOGIN_URL);
  url.searchParams.set('code', code);
  const r = await fetch(url, { redirect: 'manual', headers: { 'user-agent': 'Mozilla/5.0', 'x-client-type': 'h5' } });
  const cookies = typeof r.headers.getSetCookie === 'function'
    ? r.headers.getSetCookie()
    : [r.headers.get('set-cookie')].filter(Boolean);
  let sessionId = null, maxAge = null;
  for (const c of cookies) {
    const sm = c && c.match(/session_id=([^;]+)/);
    if (sm) {
      sessionId = sm[1];
      const am = c.match(/max-age=(\d+)/i);
      if (am) maxAge = parseInt(am[1], 10);
    }
  }
  if (!sessionId) throw new Error(`h5/login did not set session_id (HTTP ${r.status}) — the auth flow may have changed`);
  return { session_id: sessionId, expiresAt: Date.now() + (maxAge || DEFAULT_MAXAGE) * 1000 };
}

/**
 * Resolve a usable session_id. Uses the .order_session.json cache unless it's
 * missing/expired or forceRefresh is set, in which case it re-mints and rewrites
 * the cache. A hand-supplied session_id (no expiresAt) is honored until a 401.
 */
async function getSessionId(forceRefresh = false) {
  if (!forceRefresh) {
    try {
      const c = JSON.parse(fs.readFileSync(ORDER_SESSION_PATH, 'utf-8'));
      if (c?.session_id && (!c.expiresAt || c.expiresAt > Date.now())) return c.session_id;
    } catch { }
  }
  const { session_id, expiresAt } = await mintSessionId();
  fs.writeFileSync(ORDER_SESSION_PATH, JSON.stringify({
    session_id,
    expiresAt,
    _managed: 'Auto-derived from .session.json via mina + h5/login. Delete this file (or let it expire) to force a re-mint. No manual editing needed.',
  }, null, 2), 'utf-8');
  return session_id;
}

/** Whether a response means the server rejected our session_id (→ re-mint + retry once). */
function isAuthFailure(status, j) {
  if (status === 401 || status === 403) return true;
  const c = j?.code;
  if (c === 401 || c === 403) return true;
  if (c === 0 || c === 200 || c == null) return false;
  const msg = String(j?.msg || j?.message || '');
  return /session_id is empty|unauthor|not\s*login|invalid.*session|登录/i.test(msg);
}

/**
 * Authenticated inner-order request. Injects the session_id cookie, and if the
 * server rejects it, re-mints the session and retries the request exactly once.
 */
async function orderRequest(rawUrl, { method = 'GET', json } = {}, _isRetry = false) {
  const sid = await getSessionId(_isRetry);
  const headers = {
    accept: 'application/json, text/plain, */*',
    cookie: `session_id=${sid}`,
    referer: `${HOST}/canteen/ordering`,
    'x-accept-language': 'en',
    'x-catering-timezone': 'GMT-7:00',
    'x-client-type': 'h5',
  };
  const init = { method, headers };
  if (json !== undefined) {
    headers['content-type'] = 'application/json; charset=UTF-8';
    headers.origin = HOST;
    init.body = JSON.stringify(json);
  }
  const resp = await fetch(rawUrl, init);
  const text = await resp.text();
  const j = readJson(text);
  if (!_isRetry && isAuthFailure(resp.status, j)) {
    return orderRequest(rawUrl, { method, json }, true);
  }
  return { status: resp.status, json: j, raw: text };
}

/** Resolve a building: accepts a config.json key or a raw mdmCode. */
function resolveBuilding(arg) {
  const cfg = loadConfig();
  const list = cfg.buildings || [];
  if (!arg) return list[0];
  return list.find(b => b.key === arg) || list.find(b => b.mdmCode === arg) || { key: arg, mdmCode: arg, name: arg };
}

/** Read-only: fetch the orderable food-truck menu. */
async function fetchMenu(buildingCode, mealDate, timeCode) {
  const url = `${MENU_URL}?buildingCode=${encodeURIComponent(buildingCode)}&mealDate=${mealDate}&timeCode=${timeCode}&isFilterEmptyStations=1`;
  const { status, json } = await orderRequest(url);
  if (!json) fail(`menu/v3 returned non-JSON (HTTP ${status}). .session.json (LARK_SESSION) may be expired.`);
  if (json.code !== 200 && json.code !== 0) fail(`menu/v3 failed: code=${json.code} msg=${json.msg || json.message}`);
  return json.data;
}

/**
 * Read-only: resolve the ordering identity from mini-program/h5/user_info.
 * tenantEmpId = `${tenant_key}#${employee_no}`. Resolved dynamically; never hardcoded.
 */
async function fetchIdentity() {
  const { status, json } = await orderRequest(USER_INFO_URL);
  if (!json) throw new Error(`user_info returned non-JSON (HTTP ${status}). The session may have expired.`);
  if (json.code !== 200 && json.code !== 0) throw new Error(`user_info failed: code=${json.code} msg=${json.msg || json.message}`);
  const u = json.data?.user || {};
  if (!u.open_id || !u.union_id || !u.tenant_key || !u.employee_no) {
    throw new Error('user_info is missing identity fields (open_id/union_id/tenant_key/employee_no); cannot order.');
  }
  return {
    openId: u.open_id,
    unionId: u.union_id,
    tenantEmpId: `${u.tenant_key}#${u.employee_no}`,
    _name: u.name || u.en_name || '',
    _email: u.enterprise_email || u.email || '',
  };
}

/** Normalize an item into a shape that both displays well and maps to the order payload. */
function normalizeItem(site, item, building) {
  return {
    truck: site.siteLabel,
    pickupAddressCode: item.pickupAddressId || site.siteId,
    pickupAddressName: item.pickupAddress || site.siteLabel,
    name: item.name,
    skuCode: item.skuCode,
    labelMealCode: item.labelMealCode,
    currentStock: item.currentStock,
    totalStock: item.totalStock,
    soldOut: (item.currentStock ?? 0) <= 0,
    mealStartTime: item.mealStartTime,
    mealEndTime: item.mealEndTime,
    buildingCode: item.buildingCode || building.mdmCode,
    buildingName: building.name,
    mealDate: item.mealDate,
    mealType: item.mealType,
    description: item.specification || item.dishData?.description || '',
  };
}

function flattenItems(data, building) {
  const out = [];
  for (const site of data.menuSites || []) {
    for (const item of site.items || []) out.push(normalizeItem(site, item, building));
  }
  return out;
}

/** list subcommand: read-only listing of orderable food-truck items. */
async function cmdList(date, meal, buildingArg) {
  const b = resolveBuilding(buildingArg);
  const mealDate = date || new Date().toISOString().split('T')[0];
  const timeCode = meal || loadConfig().defaults?.meal || 'lunch';

  const data = await fetchMenu(b.mdmCode, mealDate, timeCode);
  const items = flattenItems(data, b);

  const ss = sessionStatus();
  const out = {
    action: 'list',
    building: { key: b.key, code: b.mdmCode, name: b.name },
    mealDate, mealType: timeCode,
    lifecycleStage: data.lifecycleStage,
    orderLimitedTime: data.orderLimitedTime,
    cancelLimitedTime: data.cancelLimitedTime,
    hadOrdered: data.hadOrdered,
    bookedOrderInfo: data.bookedOrderInfo || '',
    truckCount: (data.menuSites || []).length,
    itemCount: items.length,
    items,
  };
  if (ss.level === 'warn' || ss.level === 'expired') out.sessionWarning = ss.message;
  console.log(JSON.stringify(out, null, 2));
}

/** Build a single-order payload for submit-order/batch. */
function buildOrderPayload(item, identity) {
  return {
    openId: identity.openId,
    tenantEmpId: identity.tenantEmpId,
    unionId: identity.unionId,
    buildingName: item.buildingName,
    labelMealCode: item.labelMealCode,
    skuCode: item.skuCode,
    buildingCode: item.buildingCode,
    mealDate: item.mealDate,
    mealType: item.mealType,
    pickupAddressCode: item.pickupAddressCode,
    pickupAddressName: item.pickupAddressName,
    mealStartTime: item.mealStartTime,
    mealEndTime: item.mealEndTime,
    foodName: item.name,
  };
}

/**
 * order subcommand: pick an item and place an order.
 * Places a REAL order by default (requires complete identity + clean preflight).
 * Pass --dry-run to only print the payload and send nothing.
 */
async function cmdOrder(opts) {
  const b = resolveBuilding(opts.building);
  const mealDate = opts.date;
  const timeCode = opts.meal || 'lunch';
  if (!mealDate) fail('specify the meal date with --date YYYY-MM-DD');
  if (!opts.select) fail('specify the item to reserve with --select <skuCode|dish-name-substring>');

  // Always re-fetch the latest menu so stock/fields are current; never trust stale input.
  const data = await fetchMenu(b.mdmCode, mealDate, timeCode);
  const items = flattenItems(data, b);
  const q = opts.select.toLowerCase();
  const matches = items.filter(i => i.skuCode === opts.select || i.name.toLowerCase().includes(q));

  if (matches.length === 0) fail(`no orderable item matching "${opts.select}" (${items.length} total)`);
  if (matches.length > 1) {
    fail(`"${opts.select}" matched ${matches.length} items; use a more precise name or skuCode:\n` +
      matches.map(m => `  - ${m.name} [${m.skuCode}] @ ${m.truck}`).join('\n'));
  }
  const item = matches[0];

  // Preflight
  const issues = [];
  if (data.lifecycleStage !== 'BOOKING') issues.push(`lifecycleStage=${data.lifecycleStage} (not BOOKING; may be outside the ordering window)`);
  if (data.hadOrdered) issues.push(`an order already exists for this meal, orderId=${data.bookedOrderInfo?.orderId || '?'} (usually one order per meal)`);
  if (item.soldOut) issues.push(`currentStock=${item.currentStock} (likely sold out / not yet open)`);
  if (data.orderLimitedTime && Date.now() > Date.parse(data.orderLimitedTime.replace(' ', 'T'))) {
    issues.push(`past the order cutoff ${data.orderLimitedTime}`);
  }

  let identity = { openId: '', tenantEmpId: '', unionId: '' };
  let identityError = '';
  try {
    identity = await fetchIdentity();
  } catch (e) {
    identityError = e.message || String(e);
  }
  const identityReady = !!(identity.openId && identity.tenantEmpId && identity.unionId);
  const payload = buildOrderPayload(item, identity);

  const summary = {
    truck: item.truck,
    food: item.name,
    building: item.buildingName,
    date: item.mealDate,
    meal: item.mealType,
    pickupWindow: `${item.mealStartTime}-${item.mealEndTime}`,
    stock: `${item.currentStock}/${item.totalStock}`,
    orderDeadline: data.orderLimitedTime,
  };

  // Mask identity in the preview to avoid leaking plaintext PII into logs/transcripts.
  const mask = v => (typeof v === 'string' && v.length > 8 ? `${v.slice(0, 4)}…${v.slice(-4)}` : (v ? '***' : ''));
  const maskedPayload = {
    ...payload,
    openId: mask(payload.openId),
    unionId: mask(payload.unionId),
    tenantEmpId: payload.tenantEmpId ? `***#${String(payload.tenantEmpId).split('#')[1] || ''}` : '',
  };

  if (opts.dryRun) {
    console.log(JSON.stringify({
      action: 'order', mode: 'DRY_RUN',
      willSubmit: false,
      summary, preflightIssues: issues,
      identityReady,
      identityError: identityError || null,
      identityWho: identityReady ? `${identity._name || ''} <${identity._email || ''}>` : null,
      payloadPreview: { orders: [maskedPayload] },
      note: 'Preview only (--dry-run); no request was sent (identity fields masked). Without --dry-run this would place a REAL order.',
    }, null, 2));
    return;
  }

  // Default path: real submit (write operation)
  if (!identityReady) {
    fail(`identity not ready, cannot submit: ${identityError || 'identity triple missing'}`);
  }
  if (issues.length) {
    fail(`preflight issues found; submission aborted (verify manually if you really must force it):\n- ${issues.join('\n- ')}`);
  }

  const { status, json } = await orderRequest(SUBMIT_URL, { method: 'POST', json: { orders: [payload] } });
  console.log(JSON.stringify({
    action: 'order', mode: 'SUBMITTED', http: status,
    summary, response: json,
  }, null, 2));
}

/**
 * cancel subcommand: cancel a booked order.
 * orderId via --order, or resolved from the read-only menu's bookedOrderInfo
 * via --date/--building/--meal. Cancels for REAL by default; --dry-run only previews.
 */
async function cmdCancel(opts) {
  let orderId = opts.order;
  let info = null;
  let cancelBy = '';

  if (!orderId) {
    if (!opts.date) fail('use --order <orderId>, or --date YYYY-MM-DD [--building --meal] to locate the order to cancel');
    const b = resolveBuilding(opts.building);
    const data = await fetchMenu(b.mdmCode, opts.date, opts.meal || 'lunch');
    orderId = data.bookedOrderInfo?.orderId || data.bookedOrderId || data.orderId || '';
    info = data.bookedOrderInfo || null;
    cancelBy = data.cancelLimitedTime || '';
    if (!orderId) fail(`no order to cancel for this date/building/meal (hadOrdered=${data.hadOrdered})`);
  }

  const summary = info && info.orderId ? {
    orderId,
    food: info.foodName,
    date: info.mealDate,
    truck: info.mealSiteLabel,
    building: info.mealBuilding,
    cancelBy: cancelBy || info.cancelLimitedTime || '',
  } : { orderId, cancelBy };

  if (opts.dryRun) {
    console.log(JSON.stringify({
      action: 'cancel', mode: 'DRY_RUN', willCancel: false,
      summary, payloadPreview: { orderId },
      note: 'Preview only (--dry-run); no request was sent. Without --dry-run this would CANCEL the order for real.',
    }, null, 2));
    return;
  }

  if (cancelBy && Date.now() > Date.parse(cancelBy.replace(' ', 'T'))) {
    fail(`past the cancel cutoff ${cancelBy}; cannot cancel.`);
  }

  const { status, json } = await orderRequest(CANCEL_URL, { method: 'POST', json: { orderId } });
  console.log(JSON.stringify({
    action: 'cancel', mode: 'CANCELLED', http: status,
    summary, response: json,
  }, null, 2));
}

function parseOpts(args) {
  const o = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--dry-run') o.dryRun = true;
    else if (a === '--date') o.date = args[++i];
    else if (a === '--meal') o.meal = args[++i];
    else if (a === '--building') o.building = args[++i];
    else if (a === '--select') o.select = args[++i];
    else if (a === '--order') o.order = args[++i];
  }
  return o;
}

/** whoami subcommand: read-only — derives/validates the session and shows the ordering identity. */
async function cmdWhoami() {
  const id = await fetchIdentity();
  let expiresAt = null;
  try { expiresAt = JSON.parse(fs.readFileSync(ORDER_SESSION_PATH, 'utf-8')).expiresAt || null; } catch { }
  console.log(JSON.stringify({
    action: 'whoami',
    sessionSource: 'auto-derived from .session.json',
    sessionExpiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
    larkSession: sessionStatus(),
    name: id._name,
    email: id._email,
    openId: id.openId,
    unionId: id.unionId,
    tenantEmpId: id.tenantEmpId,
  }, null, 2));
}

async function main() {
  const [cmd, ...rest] = process.argv.slice(2);
  switch (cmd) {
    case 'list': {
      const pos = rest.filter(a => !a.startsWith('--'));
      await cmdList(pos[0], pos[1], pos[2]);
      break;
    }
    case 'whoami':
      await cmdWhoami();
      break;
    case 'order':
      await cmdOrder(parseOpts(rest));
      break;
    case 'cancel':
      await cmdCancel(parseOpts(rest));
      break;
    default:
      console.log(`San Jose food-truck ordering tool

Usage:
  node foodtruck.mjs list [date] [meal] [buildingKey]   Read-only: list orderable food-truck items
  node foodtruck.mjs whoami                              Read-only: validate session, show ordering identity
  node foodtruck.mjs order  --date YYYY-MM-DD --select <skuCode|dishName> [--meal lunch] [--building 1199Coleman] [--dry-run]
  node foodtruck.mjs cancel (--order <orderId> | --date YYYY-MM-DD [--building --meal]) [--dry-run]

Auth:
  The ordering session_id is auto-derived from the SAME Lark session as the menu API
  (.session.json / LARK_SESSION) via mina/v2/login -> h5/login, cached in .order_session.json
  (~15-day TTL) and self-healing on 401. No manual paste, no msToken, no browser needed.
  If .session.json itself is expired you'll be told to refresh it.

  order/cancel place a REAL request by default (still gated by preflight: identity ready,
  BOOKING/in-stock/before cutoff, no duplicate). Add --dry-run to preview without sending.
  order example (REAL):     node foodtruck.mjs order  --date 2026-05-21 --select "Za'atar Garlic Roasted Lamb"
  order example (preview):  node foodtruck.mjs order  --date 2026-05-21 --select "Za'atar Garlic Roasted Lamb" --dry-run`);
  }
}

main().catch(e => fail(e.message));
