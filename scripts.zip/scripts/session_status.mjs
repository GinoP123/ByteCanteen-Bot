import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

// No external dependencies (Node 18+ built-ins only) — matches the rest of the skill.

const SKILL_DIR = path.join(import.meta.dirname || '.', '..');
const CONFIG_PATH = path.join(SKILL_DIR, 'config.json');
const SESSION_PATH = path.join(SKILL_DIR, '.session.json');

const DEFAULT_TTL_DAYS = 7;   // empirical Lark web-session lifetime
const DEFAULT_WARN_DAYS = 2;  // warn once this many days (or fewer) remain

const DAY_MS = 86400000;

/**
 * Estimate the freshness of the Lark web session.
 *
 * This is a HEURISTIC: the real expiry is server-side and only known for
 * certain when an API call fails with `invalid larksession`. We estimate
 * from `.session.json`'s `updatedAt` (when the user pasted it) plus a
 * configurable TTL, so we can warn the user *before* it fails mid-request.
 *
 * @param {object}  [opts]
 * @param {number}  [opts.now]          epoch-ms "now" (injectable for tests)
 * @param {string}  [opts.sessionPath]  override .session.json path (tests)
 * @param {string}  [opts.configPath]   override config.json path (tests)
 * @returns {{level:'ok'|'warn'|'expired'|'unknown'|'absent', source:string,
 *            ageDays:number|null, daysLeft:number|null, ttlDays:number,
 *            warnDays:number, updatedAt:string|null, message:string}}
 */
export function sessionStatus({ now = Date.now(), sessionPath = SESSION_PATH, configPath = CONFIG_PATH } = {}) {
  let ttlDays = DEFAULT_TTL_DAYS;
  let warnDays = DEFAULT_WARN_DAYS;
  try {
    const d = JSON.parse(fs.readFileSync(configPath, 'utf-8')).defaults || {};
    if (Number.isFinite(d.sessionTtlDays) && d.sessionTtlDays > 0) ttlDays = d.sessionTtlDays;
    if (Number.isFinite(d.sessionWarnDays) && d.sessionWarnDays >= 0) warnDays = d.sessionWarnDays;
  } catch { /* config optional — fall back to code defaults */ }

  const base = { ttlDays, warnDays, ageDays: null, daysLeft: null, updatedAt: null };

  let file = null;
  try { file = JSON.parse(fs.readFileSync(sessionPath, 'utf-8')); } catch { /* no file */ }

  // No .session.json with a session value: maybe the env var is used instead.
  if (!file || !file.session) {
    if (process.env.LARK_SESSION) {
      return {
        ...base, level: 'unknown', source: 'env',
        message: 'Lark session is taken from $LARK_SESSION; its age is unknown, so expiry cannot be estimated. Re-export it if requests start failing with `invalid larksession`.',
      };
    }
    return {
      ...base, level: 'absent', source: 'none',
      message: 'No Lark session configured (.session.json absent and $LARK_SESSION unset). Paste your Lark web `session` cookie to set one.',
    };
  }

  // Have a file session but no usable timestamp → can't estimate.
  if (!Number.isFinite(file.updatedAt)) {
    return {
      ...base, level: 'unknown', source: 'file',
      message: 'Lark session present but has no `updatedAt`, so its age cannot be estimated. It will keep working until an API call returns `invalid larksession`.',
    };
  }

  const ageDays = Math.max(0, (now - file.updatedAt) / DAY_MS);
  const daysLeft = ttlDays - ageDays;
  const updatedAt = new Date(file.updatedAt).toISOString();
  const round = n => Math.round(n * 10) / 10;

  if (ageDays >= ttlDays) {
    return {
      ...base, level: 'expired', source: 'file', updatedAt,
      ageDays: round(ageDays), daysLeft: round(daysLeft),
      message: `Lark session is ~${round(ageDays)}d old (estimated ~${ttlDays}d lifetime) — it has likely expired. Paste a fresh Lark web \`session\` cookie before the next request.`,
    };
  }
  if (daysLeft <= warnDays) {
    return {
      ...base, level: 'warn', source: 'file', updatedAt,
      ageDays: round(ageDays), daysLeft: round(daysLeft),
      message: `Lark session is ~${round(ageDays)}d old; estimated ~${round(daysLeft)}d left (of ~${ttlDays}d). Re-paste your Lark web \`session\` cookie soon to avoid a mid-request failure.`,
    };
  }
  return {
    ...base, level: 'ok', source: 'file', updatedAt,
    ageDays: round(ageDays), daysLeft: round(daysLeft),
    message: `Lark session is ~${round(ageDays)}d old; estimated ~${round(daysLeft)}d left (of ~${ttlDays}d).`,
  };
}

// CLI: `node scripts/session_status.mjs` → print the status as JSON.
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(JSON.stringify(sessionStatus(), null, 2));
}
